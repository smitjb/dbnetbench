How to use DBNetBench

1.  Create a config file
    This is optional, but it simplifies the command line significantly.
    The contents of the config file are equivalent to command line options.
    Command line options override the config file.

  There are template config files in the program directory

    oracle.config.distrib
    postgres.config.distrib
    mysql.config.distrib
    mssql.config.distrib
    hana.config.distrib


2.  Run dbnetbench.cmd/dbnetbench.ksh
    The only required parameter is the config file name.
>dbnetbench -c myconfigfile.config
>dbnetbench --configfile=myconffigfile.config.

Any parameters which are missing from the config file, or which you want to override can be specified
on the command line.  For example, you could do multple runs with the same config file, varying the fetchsize each time.

>dbnetbench -c myconfigfile.config -z 100
>dbnetbench -c myconfigfile.config -z 1000
>dbnetbench -c myconfigfile.config -z 10000

Options.

        Usage: dbnetbench <options>
        Time the running of a single SQL query
        Intended to help investigate the network component of data retrieval
        and how it responds to changes in batch size
        Options are:
        -?               display usage
Config file
       --configfile -c   Configuration file. Any and all optiones can be
                          specified in the config file. config file option names are the same
                          as the long option name. Command line options take precedence

Connection
        --username -u     database username
        --password -w     database password
Query
        --query -q        text of query to run
        --sqlfile -f      file containing query to run. Overrides -q
        --fetchsize -z    array fetch size
Output
         --separator -t   character to separate result columns


        The main timing results are a delimited set of columns, as follows



   rows         the number of rows retrieved
   TOTAL        Total elapsed time in milliseconds
   ROWS_P_S     rows retrieved per second
   FETCHSIZE    the fetchsize used
   exec         Time spent on the execute phase in milliseconds
   fetch        Time spent on the fetch phase in milliseconds

   Depending on the nature of the query, the database may start returning
   rows before the execution is finished so the exec time may be artificially short
   Exec time won't vary much with fetchsize, but fetch time may
